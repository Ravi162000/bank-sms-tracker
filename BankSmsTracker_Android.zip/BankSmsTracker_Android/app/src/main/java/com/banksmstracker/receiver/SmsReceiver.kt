package com.banksmstracker.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import org.json.JSONArray
import org.json.JSONObject

class SmsReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_NEW_BANK_SMS = "com.banksmstracker.NEW_BANK_SMS"
        const val PREF_QUEUE = "pending_sms_queue_prefs"
        const val KEY_QUEUE = "pending_sms_json"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (messages.isNullOrEmpty()) return

        val sender = messages[0].originatingAddress ?: ""
        val body = messages.joinToString("") { it.messageBody ?: "" }
        val timestamp = messages[0].timestampMillis

        // 1. Save to background queue so SMS is never missed when app is closed
        val prefs = context.getSharedPreferences(PREF_QUEUE, Context.MODE_PRIVATE)
        val arr = try {
            JSONArray(prefs.getString(KEY_QUEUE, "[]"))
        } catch (e: Exception) {
            JSONArray()
        }
        val obj = JSONObject().apply {
            put("sender", sender)
            put("body", body)
            put("timestamp", timestamp)
        }
        arr.put(obj)
        prefs.edit().putString(KEY_QUEUE, arr.toString()).apply()

        // 2. Notify MainActivity immediately if app is currently open
        val liveIntent = Intent(ACTION_NEW_BANK_SMS).apply {
            setPackage(context.packageName)
            putExtra("sender", sender)
            putExtra("body", body)
            putExtra("timestamp", timestamp)
        }
        context.sendBroadcast(liveIntent)
    }
}
