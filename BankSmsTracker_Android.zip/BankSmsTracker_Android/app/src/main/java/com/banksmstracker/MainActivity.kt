package com.banksmstracker

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.banksmstracker.receiver.SmsReceiver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var pageReady = false
    private val notifChannelId = "bank_sms_tracker_alerts"

    // OTA Auto-Update URL (Public GitHub raw URL for instant HTML updates without reinstalling APK)
    private val otaHtmlUrl = "https://raw.githubusercontent.com/Ravi162000/bank-sms-tracker/main/bank_sms_tracker.html"
    private lateinit var localHtmlFile: File

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        val readOk = perms[Manifest.permission.READ_SMS] == true
        if (readOk) {
            syncInboxAndQueuedSms()
        } else {
            Toast.makeText(
                this,
                "SMS permission denied. Phone Settings -> Apps -> Bank SMS Tracker -> Allow restricted settings on karein.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private val liveSmsReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val sender = intent.getStringExtra("sender") ?: ""
            val body = intent.getStringExtra("body") ?: ""
            val timestamp = intent.getLongExtra("timestamp", System.currentTimeMillis())
            pushSingleSmsToWebView(sender, body, timestamp)
            clearPendingQueue()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        createNotificationChannel()

        localHtmlFile = File(filesDir, "bank_sms_tracker.html")
        ensureInitialLocalHtml()

        webView = findViewById(R.id.webView)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
        }
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AndroidSmsBridge(), "AndroidSmsBridge")
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                pageReady = true
                if (hasSmsPermission()) syncInboxAndQueuedSms()
            }
        }

        // Always load from local filesDir so localStorage stays intact across every OTA update
        webView.loadUrl("file://${localHtmlFile.absolutePath}")
        requestRequiredPermissions()

        // Silently check GitHub for a newer bank_sms_tracker.html in the background
        checkForOtaUpdate()
    }

    private fun ensureInitialLocalHtml() {
        if (!localHtmlFile.exists() || localHtmlFile.length() < 1000) {
            try {
                assets.open("bank_sms_tracker.html").use { input ->
                    FileOutputStream(localHtmlFile).use { output ->
                        input.copyTo(output)
                    }
                }
            } catch (_: Exception) {}
        }
    }

    private fun sha256(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
        return digest.joinToString("") { "%02x".format(it) }
    }

    private fun checkForOtaUpdate() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val conn = (URL("$otaHtmlUrl?t=${System.currentTimeMillis()}").openConnection() as HttpURLConnection).apply {
                    connectTimeout = 6000
                    readTimeout = 8000
                    requestMethod = "GET"
                    useCaches = false
                }
                if (conn.responseCode == 200) {
                    val newBytes = conn.inputStream.use { it.readBytes() }
                    val newText = String(newBytes, Charsets.UTF_8)
                    if (newText.contains("<!DOCTYPE html>", ignoreCase = true) && newText.contains("</html>", ignoreCase = true)) {
                        val oldHash = if (localHtmlFile.exists()) sha256(localHtmlFile.readBytes()) else ""
                        val newHash = sha256(newBytes)
                        if (newHash != oldHash) {
                            val tmpFile = File(filesDir, "bank_sms_tracker.html.tmp")
                            FileOutputStream(tmpFile).use { it.write(newBytes) }
                            tmpFile.renameTo(localHtmlFile)
                            withContext(Dispatchers.Main) {
                                Toast.makeText(this@MainActivity, "New update installed automatically!", Toast.LENGTH_SHORT).show()
                                pageReady = false
                                webView.loadUrl("file://${localHtmlFile.absolutePath}")
                            }
                        }
                    }
                }
                conn.disconnect()
            } catch (_: Exception) {
                // Offline or repo not public yet — keep using cached local HTML smoothly
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                notifChannelId,
                "Bank Transaction Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications when bank SMS transactions are auto-tracked"
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun postSystemNotification(title: String, message: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notif = NotificationCompat.Builder(this, notifChannelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        nm.notify((System.currentTimeMillis() % 100000).toInt(), notif)
    }

    override fun onResume() {
        super.onResume()
        val filter = IntentFilter(SmsReceiver.ACTION_NEW_BANK_SMS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(liveSmsReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(liveSmsReceiver, filter)
        }
        if (pageReady && hasSmsPermission()) syncInboxAndQueuedSms()
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(liveSmsReceiver) } catch (_: Exception) {}
    }

    private fun hasSmsPermission(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED &&
               ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestRequiredPermissions() {
        val perms = mutableListOf(Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = perms.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    private fun clearPendingQueue() {
        getSharedPreferences(SmsReceiver.PREF_QUEUE, Context.MODE_PRIVATE)
            .edit().remove(SmsReceiver.KEY_QUEUE).apply()
    }

    private fun syncInboxAndQueuedSms() {
        if (!hasSmsPermission()) {
            requestRequiredPermissions()
            return
        }
        CoroutineScope(Dispatchers.IO).launch {
            val batch = JSONArray()

            val prefs = getSharedPreferences(SmsReceiver.PREF_QUEUE, Context.MODE_PRIVATE)
            try {
                val queued = JSONArray(prefs.getString(SmsReceiver.KEY_QUEUE, "[]"))
                for (i in 0 until queued.length()) batch.put(queued.getJSONObject(i))
            } catch (_: Exception) {}
            clearPendingQueue()

            try {
                val cursor = contentResolver.query(
                    Uri.parse("content://sms/inbox"),
                    arrayOf("address", "body", "date"),
                    null,
                    null,
                    "date DESC"
                )
                cursor?.use { c ->
                    val idxAddr = c.getColumnIndex("address")
                    val idxBody = c.getColumnIndex("body")
                    val idxDate = c.getColumnIndex("date")
                    var count = 0
                    while (c.moveToNext() && count < 300) {
                        val obj = JSONObject().apply {
                            put("sender", c.getString(idxAddr) ?: "")
                            put("body", c.getString(idxBody) ?: "")
                            put("timestamp", c.getLong(idxDate))
                        }
                        batch.put(obj)
                        count++
                    }
                }
            } catch (_: Exception) {}

            val jsonPayload = JSONObject.quote(batch.toString())
            withContext(Dispatchers.Main) {
                if (pageReady) {
                    webView.evaluateJavascript("window.onAndroidSmsBatch($jsonPayload);", null)
                }
            }
        }
    }

    private fun pushSingleSmsToWebView(sender: String, body: String, timestamp: Long) {
        if (!pageReady) return
        val js = "window.onAndroidSmsReceived(${JSONObject.quote(sender)}, ${JSONObject.quote(body)}, $timestamp);"
        runOnUiThread { webView.evaluateJavascript(js, null) }
    }

    inner class AndroidSmsBridge {
        @JavascriptInterface
        fun syncInboxSms() {
            runOnUiThread {
                syncInboxAndQueuedSms()
                checkForOtaUpdate()
            }
        }

        @JavascriptInterface
        fun requestSmsPermission() {
            runOnUiThread { requestRequiredPermissions() }
        }

        @JavascriptInterface
        fun showNotification(title: String, message: String) {
            runOnUiThread { postSystemNotification(title, message) }
        }

        @JavascriptInterface
        fun savePdfBase64(fileName: String, base64Data: String) {
            try {
                val bytes = Base64.decode(base64Data, Base64.DEFAULT)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                        put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
                        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    if (uri != null) {
                        contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                    }
                } else {
                    val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    val file = File(dir, fileName)
                    FileOutputStream(file).use { it.write(bytes) }
                }
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "PDF saved to Downloads: $fileName", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Failed to save PDF: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
