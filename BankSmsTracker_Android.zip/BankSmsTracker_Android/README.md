# Bank SMS Tracker (Android Studio Project — Full UI + Auto SMS Tracking)

Is Android project mein **exact `bank_sms_tracker.html` wala UI** (EN/हिंदी toggle, Name top-right, Bank select, Other bank, Charts, Available/Estimated Balance, UPI Nicknames) **Android ke real SMS permission aur background BroadcastReceiver** ke saath juda hua hai.

## Phone ke liye APK Kaise Banayein (Step-by-Step)

1. Is `BankSmsTracker_Android.zip` ko unzip karein.
2. **Android Studio** open karein -> **Open** par click karke `BankSmsTracker_Android` folder select karein.
3. Gradle sync poora hone dein (1-2 minute).
4. Top menu se **Build -> Build Bundle(s) / APK(s) -> Build APK(s)** par click karein.
5. APK banne ke baad `app/build/outputs/apk/debug/app-debug.apk` ko apne Android phone mein transfer karke install karein.
6. **Important (Android 13 / 14 / 15):**
   - App open hote hi **SMS Permission** maangega.
   - Agar Android security ki wajah se SMS permission allow nahi ho rahi ho, toh phone ki **Settings -> Apps -> Bank SMS Tracker -> upar right side 3 dots -> Allow restricted settings** on karein, phir **Permissions -> SMS -> Allow** kar dein.
7. Ab app open karein, apna **Name** aur **Banks** select karein — aapke purane aur naye saare selected bank SMS apne aap track hone lagenge!
